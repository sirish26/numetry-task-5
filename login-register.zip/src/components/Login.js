
import React, { useState } from "react"
import axios from "axios"
import { useNavigate, Link } from "react-router-dom"


function Login() {

    const history=useNavigate();

    const [email,setEmail]=useState('')
    const [password,setPassword]=useState('')

    async function submit(e){
        e.preventDefault();

        try{

            await axios.post("http://localhost:8000/",{
                email,password
            })
            .then(res=>{
                if(res.data==="exist"){
                    history("/home",{state:{id:email}})
                }
                else if(res.data==="notexist"){
                    alert("User have not sign up")
                }
            })
            .catch(e=>{
                alert("wrong details")
                console.log(e);
            })

        }
        catch(e){
            console.log(e);

        }

    }


    return (
        <div className="container">
            <h2>Login</h2>
            <form action="POST">
            <div class="input-group"><input type="email" onChange={(e) => { setEmail(e.target.value) }} placeholder="Email"  /></div>
            <div class="input-group"><input type="password" onChange={(e) => { setPassword(e.target.value) }} placeholder="Password"  /></div>
            <button type="submit" onClick={submit}>Submit</button>
            </form>
            <br />
            <br />
            <div class="link">Don't have an account?<Link to="/signup">Signup</Link></div>
        </div>
    )
}

export default Login

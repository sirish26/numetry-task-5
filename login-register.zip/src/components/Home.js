import React from "react"
import {useLocation} from 'react-router-dom';

function Home (){
    const location=useLocation()

    return (
        <div className="homepage">

            <h1><center>Hello {location.state.id},welcome to the home</center></h1>

        </div>
    )
}

export default Home
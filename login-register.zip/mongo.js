
const mongoose=require("mongoose")
mongoose.connect("mongodb+srv://root:root@numerty.t7qkzms.mongodb.net/test")
.then(()=>{
    console.log("mongodb connected");
})
.catch(()=>{
    console.log(' connection failed');
})


const newSchema=new mongoose.Schema({
    email:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    }
})

const collection = mongoose.model("login-register",newSchema)

module.exports=collection

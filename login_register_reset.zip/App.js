import React from 'react';
import './App.css';
import Login from './components/Login';
import Signup from './components/Signup';
import ResetPassword from './components/ResetPassword';
import VerifyOTP from './components/VerifyOTP';
import UpdatePassword from './components/UpdatePassword';

function App() {
  const path = window.location.pathname;

  const renderComponent = () => {
    switch (path) {
      case '/signup':
        return <Signup />;
      case '/login':
        return <Login />;
      case '/reset-password':
        return <ResetPassword />;
      case '/verify-otp':
        return <VerifyOTP />;
      case '/update-password':
        return <UpdatePassword />;
      default:
        return <Login />;
    }
  };

  return (
    <div className="App">
      {renderComponent()}
    </div>
  );
}

export default App;

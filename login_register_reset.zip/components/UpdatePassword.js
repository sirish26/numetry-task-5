import React, { useState } from 'react';
import axios from 'axios';

const UpdatePassword = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleUpdatePassword = async () => {
    if (password !== confirmPassword) {
      setMessage('Passwords do not match');
      return;
    }

    try {
      const response = await axios.post('http://localhost:5000/update-password', {
        password: password,
        confirmPassword: confirmPassword,
      });
      setMessage(response.data.message);
    } catch (error) {
      setMessage('Error updating password');
    }
  };

  return (
    <div className='reset-password-form'>
      <h2>Update Password</h2>
      <div>{message}</div>
      <form onSubmit={handleUpdatePassword}>
        <label>New Password</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <label>Confirm Password</label>
        <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
        <button type="submit">Update Password</button>
      </form>
    </div>
  );
};

export default UpdatePassword;

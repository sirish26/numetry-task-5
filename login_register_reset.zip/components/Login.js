import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom'; 

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:5000/login', { email, password });
      if (response.data.success) {
        alert('Login successful.');
        history.push('/home');
      } else {
        alert('Invalid email or password.');
      }
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  return (
    <div className="login-form">
      <h2>Login</h2>
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleLogin}>Login</button>
     <center> <p>Don't have an account? <a href="/signup">Signup</a></p></center>
     <center> <p>Forgotten Password? <a href="/reset-password">Reset</a></p></center>
    </div>
  );
}

export default Login;

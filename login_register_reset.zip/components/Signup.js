import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom'; 

function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory(); 

  const handleSignup = async () => {
    try {
      const response = await axios.post('http://localhost:5000/register', { email, password });
      if (response.data.success) {
        alert('Signup successful.');
        history.push('/home');
      } else {
        alert('User already exists.');
      }
    } catch (error) {
      console.error('Error signing up:', error);
    }
  };

  return (
    <div className="signup-form">
      <h2>Sign Up</h2>
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleSignup}>Signup</button>
      <center><p>Already have an account? <a href="/login">Login</a></p></center>
    </div>
  );
}

export default Signup;

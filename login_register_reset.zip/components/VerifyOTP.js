import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom'; 

function VerifyOTP() {
  const [otp, setOTP] = useState('');
  const [error, setError] = useState('');
  const history = useHistory();

  const handleVerifyOTP = async () => {
    try {
      const response = await axios.post('http://localhost:5000/verify-otp', { otp });
      if (response.data.success) {
        alert('OTP verified successfully.');
        history.push('/update-password');
      } else {
        setError('Invalid OTP. Please try again.');
      }
    } catch (error) {
      console.error('Error verifying OTP:', error);
      setError('Error verifying OTP. Please try again.');
    }
  };

  return (
    <div className="verify-otp-form">
      <h2>Verify OTP</h2>
      <input type="text" placeholder="Enter OTP" value={otp} onChange={(e) => setOTP(e.target.value)} />
      {error && <p className="error">{error}</p>}
      <button onClick={handleVerifyOTP}>Verify OTP</button>
    </div>
  );
}

export default VerifyOTP;

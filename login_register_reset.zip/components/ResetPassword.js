import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom'; 

function ResetPassword() {
  const [email, setEmail] = useState('');
  const history = useHistory();

  const handleResetPassword = async () => {
    try {
      const response = await axios.post('http://localhost:5000/reset-password', { email });
      if (response.data.success) {
        alert('OTP sent to your email.');
        history.push('/verify-otp');
      } else {
        alert('User not found.');
      }
    } catch (error) {
      console.error('Error resetting password:', error);
    }
  };

  return (
    <div className="reset-password-form">
      <h2>Reset Password</h2>
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <button onClick={handleResetPassword}>Reset Password</button>
    </div>
  );
}

export default ResetPassword;
